
/**********************************************************************
 * file:  sr_router.c
 * date:  Mon Feb 18 12:50:42 PST 2002
 * Contact: casado@stanford.edu
 *
 * Description:
 *
 * This file contains all the functions that interact directly
 * with the routing table, as well as the main entry method
 * for routing.
 *
 **********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>

#include "sr_if.h"
#include "sr_rt.h"
#include "sr_router.h"
#include "sr_protocol.h"
#include "sr_arpcache.h"
#include "sr_utils.h"

#define DEBUG 0

/*---------------------------------------------------------------------
 * Method: sr_init(void)
 * Scope:  Global
 *
 * Initialize the routing subsystem
 *
 *---------------------------------------------------------------------*/

void print(char *str, ...) {
  if (DEBUG) {
  }
}

void sr_init(struct sr_instance* sr)
{
    /* REQUIRES */
    assert(sr);

    /* Initialize cache and cache cleanup thread */
    sr_arpcache_init(&(sr->cache));

    pthread_attr_init(&(sr->attr));
    pthread_attr_setdetachstate(&(sr->attr), PTHREAD_CREATE_JOINABLE);
    pthread_attr_setscope(&(sr->attr), PTHREAD_SCOPE_SYSTEM);
    pthread_attr_setscope(&(sr->attr), PTHREAD_SCOPE_SYSTEM);
    pthread_t thread;

    pthread_create(&thread, &(sr->attr), sr_arpcache_timeout, sr);
  
    /* Add initialization code here! */

} /* -- sr_init -- */

int packet_is_addressed_to_host(struct sr_instance* sr, uint32_t target_ip) 
{
  struct sr_if* curr_if = sr->if_list;

  while (curr_if) {
    if (ntohl(curr_if->ip) == ntohl(target_ip)) {
      return 1; 
    }
    curr_if = curr_if->next;
  }
  print("Packet is not addressed to host.\n");
  return 0;
}

void set_eth_packet_hdr(uint8_t *packet, uint8_t *src_mac, uint8_t *dst_mac, uint16_t eth_type) 
{
  sr_ethernet_hdr_t *ehdr = (sr_ethernet_hdr_t *) packet;
  memcpy(ehdr->ether_shost, src_mac, ETHER_ADDR_LEN);
  memcpy(ehdr->ether_dhost, dst_mac, ETHER_ADDR_LEN);
  ehdr->ether_type = htons(eth_type);
}

void set_arp_req_hdr(sr_arp_hdr_t *arp_hdr) 
{
    arp_hdr->ar_hrd = htons(arp_hrd_ethernet);
    arp_hdr->ar_pro = htons(ethertype_ip); /** TODO doublecheck ethertype ip - arp is ip? **/
    arp_hdr->ar_hln = 6; /** Ethernet address size is 6 **/
    arp_hdr->ar_pln = 4; /** IPV address size is 4 **/
}

void set_arp_packet_hdr(uint8_t *packet, unsigned char *src_mac, 
                        unsigned char *target_mac, 
                        uint32_t src_ip, uint32_t target_ip, 
                        unsigned short ar_op) 
{
  sr_arp_hdr_t *arp_hdr = (sr_arp_hdr_t *) (packet + sizeof(sr_ethernet_hdr_t));

  memcpy(arp_hdr->ar_sha, src_mac, ETHER_ADDR_LEN);
  memcpy(arp_hdr->ar_tha, target_mac, ETHER_ADDR_LEN);

  arp_hdr->ar_sip = src_ip;
  arp_hdr->ar_tip = target_ip;
  arp_hdr->ar_op = htons(ar_op);

  if (ar_op == arp_op_request) {
    set_arp_req_hdr(arp_hdr);
  } else if (ar_op == arp_op_reply) {
    /** Do reply **/
  }
}

void ip_hdr_compute_cksum(sr_ip_hdr_t *ip_hdr) {
  ip_hdr->ip_sum = 0;
  ip_hdr->ip_sum = cksum(ip_hdr, (ip_hdr->ip_hl) * 4);
}

void set_ip_packet_hdr(uint8_t *packet, uint32_t src_ip, uint32_t dst_ip) 
{
  sr_ip_hdr_t *ip_hdr = (sr_ip_hdr_t *) (packet + (sizeof(sr_ethernet_hdr_t)));
  ip_hdr->ip_src = src_ip;
  ip_hdr->ip_dst = dst_ip;
  ip_hdr_compute_cksum(ip_hdr);
}

void process_arp_request(struct sr_instance* sr, uint8_t *packet, unsigned int len, char *interface) 
{
  sr_arp_hdr_t *arp_hdr = (sr_arp_hdr_t *) (packet + sizeof(sr_ethernet_hdr_t));
  uint32_t target_ip = ntohl(arp_hdr->ar_tip);
  struct sr_if* curr_if = sr->if_list;

  /** struct sr_arpreq *arp_req =  sr_arpcache_insert(&(sr->cache), arp_hdr->ar_sha, arp_hdr->ar_sip); **/

  while (curr_if) {
    if (ntohl(curr_if->ip) == target_ip) {
      unsigned char src_mac[ETHER_ADDR_LEN];
      unsigned char dst_mac[ETHER_ADDR_LEN];
      memcpy(src_mac, curr_if->addr, ETHER_ADDR_LEN);
      memcpy(dst_mac, arp_hdr->ar_sha, ETHER_ADDR_LEN);

      set_arp_packet_hdr(packet, src_mac, dst_mac, curr_if->ip, arp_hdr->ar_sip, arp_op_reply);
      set_eth_packet_hdr(packet, (uint8_t *) src_mac, (uint8_t *) dst_mac, ethertype_arp);
      /* still need to cache ip->mac mapping */
      sr_send_packet(sr, packet, len, interface);
      return;
    }
    curr_if = curr_if->next;
  }
  
}

void set_icmp_hdr_t0(uint8_t *new_packet, uint8_t *packet, icmp_type_t type) 
{
  sr_ip_hdr_t *ip_hdr = (sr_ip_hdr_t *) (packet + sizeof(sr_ethernet_hdr_t));
  unsigned int size = ntohs(ip_hdr->ip_len) - (ip_hdr->ip_hl * 4);
  sr_icmp_hdr_t *icmp_hdr = (sr_icmp_hdr_t *) (new_packet + sizeof(sr_ethernet_hdr_t) + sizeof(sr_ip_hdr_t));
  icmp_hdr->icmp_type = type;
  icmp_hdr->icmp_sum = 0;
  icmp_hdr->icmp_sum = cksum(icmp_hdr, size);
}

void set_icmp_hdr_t3(uint8_t *new_packet, uint8_t *packet, icmp_code_t code) 
{
  sr_icmp_t3_hdr_t *icmp_hdr = (sr_icmp_t3_hdr_t *) (new_packet + sizeof(sr_ethernet_hdr_t) + sizeof(sr_ip_hdr_t));
  sr_ip_hdr_t *ip_hdr = (sr_ip_hdr_t *) (packet + sizeof(sr_ethernet_hdr_t));
  unsigned int size = ntohs(ip_hdr->ip_len) - (ip_hdr->ip_hl * 4);

  /** ICMP packet must be copied *before* we modify the IP header **/
  uint8_t updated_datagram[ICMP_DATA_SIZE];
  memcpy(updated_datagram, 
         ip_hdr, 
         sizeof(sr_ip_hdr_t));
  memcpy(updated_datagram + sizeof(sr_ip_hdr_t),
         packet + sizeof(sr_ethernet_hdr_t) + sizeof(sr_ip_hdr_t),
         8);
  memcpy(icmp_hdr->data,
         updated_datagram,
         ICMP_DATA_SIZE);

  icmp_hdr->icmp_type = icmp_destination_unreachable_type;
  icmp_hdr->icmp_code = code;
  icmp_hdr->icmp_sum = 0;
  icmp_hdr->icmp_sum = cksum(icmp_hdr, size);
}

void set_icmp_hdr_t11(uint8_t *new_packet, uint8_t *packet, icmp_code_t code) 
{
  sr_icmp_t11_hdr_t *icmp_hdr = (sr_icmp_t11_hdr_t *) (new_packet + sizeof(sr_ethernet_hdr_t) + sizeof(sr_ip_hdr_t));
  sr_ip_hdr_t *ip_hdr = (sr_ip_hdr_t *) (packet + sizeof(sr_ethernet_hdr_t));
  unsigned int size = ntohs(ip_hdr->ip_len) - (ip_hdr->ip_hl * 4);

  /** ICMP packet must be copied *before* we modify the IP header **/
  uint8_t updated_datagram[ICMP_DATA_SIZE];
  memcpy(updated_datagram,
         ip_hdr, 
         ICMP_DATA_SIZE); 
  memcpy(icmp_hdr->data,
         updated_datagram,
         ICMP_DATA_SIZE);

  icmp_hdr->icmp_type = icmp_time_exceeded_type;
  icmp_hdr->icmp_code = code;
  icmp_hdr->icmp_sum = 0;
  icmp_hdr->icmp_sum = cksum(icmp_hdr, size);
}

void send_icmp_packet(struct sr_instance* sr, 
                      uint8_t *packet, 
                      unsigned int len, 
                      char *interface, 
                      icmp_type_t type, 
                      icmp_code_t code) 
{
  print(">> Sending ICMP Packet\n");
  sr_ip_hdr_t *ip_hdr = (sr_ip_hdr_t *) (packet + (sizeof(sr_ethernet_hdr_t)));     
  uint8_t *new_packet = malloc(sizeof(sr_ethernet_hdr_t) + sizeof(sr_ip_hdr_t) + sizeof(sr_icmp_t3_hdr_t)); 
  sr_ip_hdr_t *new_ip_hdr = (sr_ip_hdr_t *) (new_packet + (sizeof(sr_ethernet_hdr_t)));     
  struct sr_rt* next_hop_rt = get_next_hop(sr, ip_hdr->ip_src);
  struct sr_if *next_hop_interface = sr_get_interface(sr, next_hop_rt->interface);
  switch (type) {
      case icmp_echo_reply_type:
        set_icmp_hdr_t0(new_packet, packet, type);
        set_ip_packet_hdr(new_packet, ip_hdr->ip_dst, ip_hdr->ip_src);
        break;
      case icmp_destination_unreachable_type:
        set_icmp_hdr_t3(new_packet, packet, code);
        printf("SENDING DEST UNREACHABLE...\n\n\n");
        if (code == icmp_port_unreachable_code) {
          set_ip_packet_hdr(new_packet, next_hop_interface->ip, ip_hdr->ip_src);
        } else {
          set_ip_packet_hdr(new_packet, next_hop_interface->ip, ip_hdr->ip_src);
        }
        new_ip_hdr->ip_len = htons(sizeof(sr_ip_hdr_t) + sizeof(sr_icmp_t3_hdr_t));
        break;
      case icmp_time_exceeded_type:
        set_icmp_hdr_t11(new_packet, packet, code);
        new_ip_hdr->ip_len = htons(sizeof(sr_ip_hdr_t) + sizeof(sr_icmp_t3_hdr_t));
        set_ip_packet_hdr(new_packet, next_hop_interface->ip, ip_hdr->ip_src);
        break;
      default:
        break;
  }

  new_ip_hdr->ip_ttl = 64;
  new_ip_hdr->ip_p = ip_protocol_icmp;
  new_ip_hdr->ip_tos = ip_hdr->ip_tos;
  new_ip_hdr->ip_id = ip_hdr->ip_id;
  new_ip_hdr->ip_off = ip_hdr->ip_off;
  new_ip_hdr->ip_hl = ip_hdr->ip_hl;
  new_ip_hdr->ip_v = ip_hdr->ip_v;
  
  if (!next_hop_rt) {

  }

  ip_hdr_compute_cksum(new_ip_hdr);
    struct sr_arpentry* arp_entry = sr_arpcache_lookup(&(sr->cache), next_hop_rt->gw.s_addr);
    if (arp_entry) {
      /* Forward the packet to arp_entry->mac */
      set_eth_packet_hdr(new_packet, next_hop_interface->addr, arp_entry->mac, ethertype_ip);
      print_hdrs(new_packet, len);
      sr_send_packet(sr, new_packet, len, next_hop_rt->interface);
      free(arp_entry);
      free(new_packet);
    } else {
      print("ARP Cache miss. Sending request...\n");
      sr_arpcache_queuereq(&(sr->cache), next_hop_rt->gw.s_addr, new_packet, len, next_hop_rt->interface);
    }
  }

  uint32_t get_lpm(struct sr_instance* sr, uint32_t dst_ip) {
    struct sr_rt* curr_rt_entry = sr->routing_table;
    uint32_t matching_address = 0;
    int longest_match_length = 0;
    while (curr_rt_entry) {
      uint64_t prefix = curr_rt_entry->gw.s_addr & curr_rt_entry->mask.s_addr;
      if ((prefix ^ dst_ip) == 0 && curr_rt_entry->mask.s_addr > longest_match_length) {
        longest_match_length = curr_rt_entry->mask.s_addr;
        matching_address = curr_rt_entry->gw.s_addr;
      }
      curr_rt_entry = curr_rt_entry->next;
    }
    return matching_address;
  }
  struct sr_rt* sr_lpm(struct sr_instance* sr, uint32_t ip) { if(sr->routing_table == 0) { printf(" *warning* Routing table empty \n"); return 0; } struct sr_rt* rt_entry_match = 0; struct sr_rt* rt_walker = 0; rt_walker = sr->routing_table; while(rt_walker) { uint32_t rt_entry_prefix = (ntohl(rt_walker->dest.s_addr) & ntohl(rt_walker->mask.s_addr)); uint32_t ip_prefix = (ntohl(ip) & ntohl(rt_walker->mask.s_addr)); if (((rt_entry_prefix == ip_prefix) && (!rt_entry_match)) || ((rt_entry_prefix == ip_prefix) && (ntohl(rt_walker->mask.s_addr) > ntohl(rt_entry_match->mask.s_addr)))) { rt_entry_match = rt_walker; } rt_walker = rt_walker->next; } return rt_entry_match; }
  struct sr_rt* get_next_hop(struct sr_instance* sr, uint32_t dst_ip) 
  {
    return sr_lpm(sr, dst_ip);
    struct sr_rt* curr_rt_entry = sr->routing_table;
    uint32_t lpm_match = get_lpm(sr, dst_ip);
    while (curr_rt_entry) {
      /** TODO: Check if we need to do LPM **/
      if (curr_rt_entry->dest.s_addr == lpm_match) {
        return curr_rt_entry;
      }
      curr_rt_entry = curr_rt_entry->next;
    }
    return NULL;
  }

  void forward_ip_packet(struct sr_instance* sr, uint8_t *packet, unsigned int len, char *interface) 
  {
    struct sr_if* next_hop_interface;
    sr_ip_hdr_t *ip_hdr = (sr_ip_hdr_t *) (packet + (sizeof(sr_ethernet_hdr_t)));     
    uint32_t dst = ip_hdr->ip_dst;
    ip_hdr_compute_cksum(ip_hdr);
    struct sr_rt* next_hop_rt = get_next_hop(sr, dst);

    if (!next_hop_rt) {
      send_icmp_packet(sr, packet, len, interface, icmp_destination_unreachable_type, icmp_net_unreachable_code);
      return;
    }

    struct sr_arpentry* arp_entry = sr_arpcache_lookup(&(sr->cache), next_hop_rt->gw.s_addr);
    len = sizeof(sr_ethernet_hdr_t) + ip_hdr->ip_len;
    if (arp_entry) {
      /* Forward the packet to arp_entry->mac */
      next_hop_interface = sr_get_interface(sr, next_hop_rt->interface);
      set_eth_packet_hdr(packet, next_hop_interface->addr, arp_entry->mac, ethertype_ip);
      sr_send_packet(sr, packet, len, next_hop_rt->interface);
      free(arp_entry);
    } else {
      print("ARP Cache miss. Sending request...\n");
      sr_arpcache_queuereq(&(sr->cache), next_hop_rt->gw.s_addr, packet, len, next_hop_rt->interface);
    }
  }
  /** TODO how long should the TTL be in packets we send out? **/
  void process_ip_packet(struct sr_instance* sr, uint8_t *packet, unsigned int len, char *interface) 
  {
    sr_ip_hdr_t *ip_hdr = (sr_ip_hdr_t *) (packet + (sizeof(sr_ethernet_hdr_t)));     
    uint16_t ip_cksum = ip_hdr->ip_sum;
    ip_hdr_compute_cksum(ip_hdr);
    /** TODO don't hardcode size **/
    if (ip_hdr->ip_sum != ip_cksum || ip_hdr->ip_len < 20) {
      /** DO NOTHING **/
      return;
    } 

    print("The IP packet ttl: %u\n", ip_hdr->ip_ttl);

    if (packet_is_addressed_to_host(sr, ip_hdr->ip_dst)) {
      print("IP packet is meant for host\n");

      if (ip_hdr->ip_p == ip_protocol_icmp) {
        print("Processing ICMP packet\n");
        sr_icmp_hdr_t *icmp_hdr = (sr_icmp_hdr_t *) (packet + sizeof(sr_ethernet_hdr_t) + sizeof(sr_ip_hdr_t));

        switch (icmp_hdr->icmp_type) {
          case icmp_echo_request_type: /** echo request! **/
            print("Processing ICMP echo request\n");
            uint16_t icmp_cksum = icmp_hdr->icmp_sum;
            icmp_hdr->icmp_sum = 0;
            icmp_hdr->icmp_sum = (cksum(icmp_hdr, ntohs(ip_hdr->ip_len) - 20));
            if (icmp_cksum == icmp_hdr->icmp_sum) {
              send_icmp_packet(sr, packet, len, interface, icmp_echo_reply_type, icmp_echo_reply_code);
            } else {
            }
            break;
        }
      } else if (ip_hdr->ip_p == ip_protocol_tcp || ip_hdr->ip_p == ip_protocol_udp) {
        print("Processing TCP packet\n");
        send_icmp_packet(sr, packet, len, interface, icmp_destination_unreachable_type, icmp_port_unreachable_code);
      } 
    } else { /** Packet is not addressed to us, pass it on **/
      print("IP packet is not meant for host.\n");
      if (ip_hdr->ip_ttl == 1) {
        print("IP packet has died :( \n");
        send_icmp_packet(sr, packet, len, interface, icmp_time_exceeded_type, icmp_time_exceeded_code);
        return;
      }
      ip_hdr->ip_ttl--;
      forward_ip_packet(sr, packet, len, interface);
    }

  }

  /** If arp reply not for us, TODO: ignore arp reply **/
  void process_arp_reply(struct sr_instance* sr, uint8_t *packet, unsigned int len, char* interface) 
  {
    sr_arp_hdr_t *arp_hdr = (sr_arp_hdr_t *) (packet + (sizeof(sr_ethernet_hdr_t)));
    unsigned char src_mac[ETHER_ADDR_LEN];
    uint32_t src_ip = arp_hdr->ar_sip;
    struct sr_if *outgoing_interface;
    memcpy(src_mac, arp_hdr->ar_sha, ETHER_ADDR_LEN);
    struct sr_arpreq *arp_req = sr_arpcache_insert(&(sr->cache), src_mac, src_ip); 

    if (arp_req) {
      struct sr_packet *curr_packet = arp_req->packets;
      while (curr_packet) {
        outgoing_interface = sr_get_interface(sr, curr_packet->iface);
        set_eth_packet_hdr(curr_packet->buf, outgoing_interface->addr, src_mac, ethertype_ip);
        sr_send_packet(sr, curr_packet->buf, curr_packet->len, curr_packet->iface);
        print_hdrs(curr_packet->buf, len);
        printf("FROM ARP REPLY\n");
        curr_packet = curr_packet->next;
      }
      sr_arpreq_destroy(&(sr->cache), arp_req);
    } else {
     /** TODO what if arp reply doesn't cause a cache hit? **/
    } 
  }



  /*---------------------------------------------------------------------
   * Method: sr_handlepacket(uint8_t* p,char* interface)
   * Scope:  Global
   *
   * This method is called each time the router receives a packet on the
   * interface.  The packet buffer, the packet length and the receiving
   * interface are passed in as parameters. The packet is complete with
   * ethernet headers.
   *
   * Note: Both the packet buffer and the character's memory are handled
   * by sr_vns_comm.c that means do NOT delete either.  Make a copy of the
   * packet instead if you intend to keep it around beyond the scope of
   * the method call.
   *
   *---------------------------------------------------------------------*/
  void sr_handlepacket(struct sr_instance* sr,
          uint8_t * packet/* lent */,
          unsigned int len,
          char* interface/* lent */)
  {
    /* REQUIRES */
    assert(sr);
    assert(packet);
    assert(interface);

     printf("*** -> Received packet of length %d \n",len);
     print_hdrs(packet, len); 

    sr_ethernet_hdr_t *ehdr = (sr_ethernet_hdr_t *) packet;
    uint16_t eth_type = ntohs(ehdr->ether_type);

    if (eth_type == ethertype_arp) {
      print("Processing ARP packet\n");
      sr_arp_hdr_t *arp_hdr = (sr_arp_hdr_t *) (packet + sizeof(sr_ethernet_hdr_t));

      if (ntohs(arp_hdr->ar_op) == arp_op_request) {
        print("Processing ARP request\n");
        process_arp_request(sr, packet, len, interface);
      } else if (ntohs(arp_hdr->ar_op) == arp_op_reply) {
        print("Processing ARP reply\n");
        process_arp_reply(sr, packet, len, interface);
    }

  } else if (eth_type == ethertype_ip) {
    print("Processing IP packet\n");
    process_ip_packet(sr, packet, len, interface);
  }

}/* end sr_ForwardPacket */
